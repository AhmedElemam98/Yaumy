import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import '../models/post.dart';

class Posts with ChangeNotifier {
  final String _userId;
  final postsRef = Firestore.instance.collection('posts');

  Posts(this._userId,this._posts);

  List<Post> _posts = [];

  List<Post> get posts {
    return [..._posts];
  }

  Future<void> addPost() async{
    await postsRef.document(_userId).collection('userPosts').document().setData({

    });


  }
}
