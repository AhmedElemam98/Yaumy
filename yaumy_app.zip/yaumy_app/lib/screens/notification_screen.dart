import 'package:flutter/material.dart';
import '../utilities/constants.dart';
class NotificationScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Container(
          height: double.infinity,
          width: double.infinity,
          decoration: kBackgroundDecoration,));
  }
}
