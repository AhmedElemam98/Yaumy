import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../utilities/constants.dart';
import 'package:flutter_svg/svg.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:provider/provider.dart';
import '../providers/user.dart';

class UploadPostScreen extends StatefulWidget {
  @override
  _UploadPostScreenState createState() => _UploadPostScreenState();
}

class _UploadPostScreenState extends State<UploadPostScreen> {
  File _image;

  Future<void> _handleImage(ImageSource imgSrc) async {
    Navigator.pop(context);
    File file = await ImagePicker.pickImage(
        source: imgSrc,
        maxHeight: 675,
        maxWidth: 960);
    setState(() {
      _image = file;
    });
  }

  _selectImage(BuildContext parentContext) {
    return showDialog(
        context: parentContext,
        builder: (context) {
          return SimpleDialog(
            title: Text('create post'),
            children: <Widget>[
              SimpleDialogOption(
                child: Text('Photo with camera'),
                onPressed: () => _handleImage(ImageSource.camera),
              ),
              SimpleDialogOption(
                child: Text('Image from gallery'),
                onPressed: () => _handleImage(ImageSource.gallery),
              ),
              SimpleDialogOption(
                child: Text('Cancle'),
                onPressed: () => Navigator.pop(context),
              ),
            ],
          );
        });
  }

  void _clearImage() {
    setState(() {
      _image = null;
    });
  }

  Widget _createPost(String photoUrl) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0XFF61045f),
        centerTitle: true,
        title: Text(
          'share Post',
        ),
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back,
          ),
          onPressed: _clearImage,
        ),
        actions: <Widget>[
          FlatButton(
            child: Text(
              'post',
              style: TextStyle(
                  color: Colors.redAccent,
                  fontSize: 20.0,
                  fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
      body: Container(
        height: double.infinity,
        width: double.infinity,
        color: Colors.white30,
        child: ListView(
          padding: EdgeInsets.all(8),
          children: <Widget>[
            Container(
              height: 220,
              width: MediaQuery.of(context).size.width,
              child: AspectRatio(
                aspectRatio: 16 / 9,
                child: Container(
                  decoration: BoxDecoration(
                      color: Color(0XFF61045f),
                      image: DecorationImage(
                        fit: BoxFit.cover,
                        image: FileImage(_image),
                      )),
                ),
              ),
            ),
            SizedBox(
              height: 15,
            ),
            ListTile(
              leading: CircleAvatar(
                backgroundImage: NetworkImage(photoUrl),
                backgroundColor: Colors.redAccent,
              ),
              title: Container(
                child: TextField(
                  decoration: InputDecoration(
                      hintText: "Write a Caption...", border: InputBorder.none),
                ),
              ),
            ),
            Divider(),
            ListTile(
              leading: Icon(
                Icons.pin_drop,
                color: Colors.redAccent,
                size: 35,
              ),
              title: Container(
                child: TextField(
                  decoration: InputDecoration(
                      hintText: "Where was this photo token?...",
                      border: InputBorder.none),
                ),
              ),
            ),
            Container(
              width: 200,
              height: 100,
              alignment: Alignment.center,
              child: RaisedButton.icon(
                  color: Colors.redAccent,
                  onPressed: () {},
                  icon: Icon(
                    Icons.my_location,
                    color: Colors.white,
                  ),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30.0)),
                  label: Text(
                    'Use current location',
                    style: TextStyle(color: Colors.white),
                  )),
            )
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final user = Provider.of<User>(context).currentUser;
    return Scaffold(
      body: _image != null
          ? _createPost(user.photoUrl)
          : Container(
              height: double.infinity,
              width: double.infinity,
              decoration: kBackgroundDecoration,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  SvgPicture.asset(
                    'assets/logos/upload.svg',
                    height: 260,
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  RaisedButton(
                    color: Colors.redAccent,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8)),
                    child: Text(
                      'upload Image',
                      style: TextStyle(color: Colors.white, fontSize: 22),
                    ),
                    onPressed: () => _selectImage(context),
                  ),
                ],
              ),
            ),
    );
  }
}
